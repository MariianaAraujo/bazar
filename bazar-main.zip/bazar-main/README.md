# AluraFlix imersao.dev!

Esse foi o projeto onde eu aprendi a fazer um site

